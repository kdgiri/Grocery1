'use strict';

describe('Service: restcall', function () {

  // load the service's module
  beforeEach(module('groceryApp'));

  // instantiate service
  var restcall;
  beforeEach(inject(function (_restcall_) {
    restcall = _restcall_;
  }));

  it('should do something', function () {
    expect(!!restcall).toBe(true);
  });

});
