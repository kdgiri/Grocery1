'use strict';

describe('Service: c', function () {

  // instantiate service
  var c,
    init = function () {
      inject(function (_c_) {
        c = _c_;
      });
    };

  // load the service's module
  beforeEach(module('groceryApp'));

  it('should do something', function () {
    init();

    expect(!!c).toBe(true);
  });

  it('should be configurable', function () {
    module(function (cProvider) {
      cProvider.setSalutation('Lorem ipsum');
    });

    init();

    expect(c.greet()).toEqual('Lorem ipsum');
  });

});
