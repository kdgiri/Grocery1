'use strict';

describe('Service: restGet', function () {

  // load the service's module
  beforeEach(module('groceryApp'));

  // instantiate service
  var restGet;
  beforeEach(inject(function (_restGet_) {
    restGet = _restGet_;
  }));

  it('should do something', function () {
    expect(!!restGet).toBe(true);
  });

});
