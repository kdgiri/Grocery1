'use strict';

describe('Controller: GroceryhomeCtrl', function () {

  // load the controller's module
  beforeEach(module('groceryApp'));

  var GroceryhomeCtrl,
    scope;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    GroceryhomeCtrl = $controller('GroceryhomeCtrl', {
      $scope: scope
      // place here mocked dependencies
    });
  }));

  it('should attach a list of awesomeThings to the scope', function () {
    expect(GroceryhomeCtrl.awesomeThings.length).toBe(3);
  });
});
