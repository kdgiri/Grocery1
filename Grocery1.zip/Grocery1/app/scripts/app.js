'use strict';

/**
 * @ngdoc overview
 * @name groceryApp
 * @description
 * # groceryApp
 *
 * Main module of the application.
 */
angular
  .module('groceryApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'ui.router',
    'ngMessages',
    'angularModalService'
  ])
  .config(function ($routeProvider,$stateProvider,$urlRouterProvider,cProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl',
        controllerAs: 'main'
      })
      .when('/about', {
        templateUrl: 'views/about.html',
        controller: 'AboutCtrl',
        controllerAs: 'about'
      })
      .when('/groceryHome', {
        templateUrl: 'views/groceryhome.html',
        controller: 'GroceryhomeCtrl',
        controllerAs: 'groceryHome'
      })
      .when('/about',{
      templateUrl:'views/about.html',
      controller:'AboutCtrl'
      })
      .otherwise({
        redirectTo: 'views/main.html'
      });

      $stateProvider.state('uirouting',
    {
      templateUrl:'views/uirouting.html'
    }
        )
      cProvider.setSalutation("Happy shopping");
      console.log("4");
  });
