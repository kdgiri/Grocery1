'use strict';

/**
 * @ngdoc function
 * @name groceryApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the groceryApp
 */
angular.module('groceryApp')
  .controller('AboutCtrl', function ($scope,$location) {
    
    $scope.addNumber={};
    
    
    $scope.home=function()
    {

    	$location.path('/');
    }
    $scope.show=function()
    {
    	 
        $location.path('/');
       window.location.reload(); 
    }

  });
