'use strict';

/**
 * @ngdoc function
 * @name groceryApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the groceryApp
 */
angular.module('groceryApp')
  .controller('MainCtrl', function ($scope,cartService) {
    /*this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];*/

 $scope.rows = cartService.list;
  $scope.temp = false;
  
  $scope.addRow = function(){
    $scope.temp = false;
    $scope.addName="";
  };
  

  $scope.deleteRow = function(row){
    
 cartService.deleteItem(row);
  };
  
   $scope.plural = function (tab){
    return tab.length > 1 ? 's': ''; 
  };
  
  $scope.addTemp = function(){
    if($scope.temp) $scope.rows.pop(); 
    else if($scope.addName) $scope.temp = true;
    
    if($scope.addName) $scope.rows.push($scope.addName);
    else $scope.temp = false;
  };
  
  $scope.isadded = function(i){
    return i==$scope.rows.length-1 && $scope.temp;
  };

  });
