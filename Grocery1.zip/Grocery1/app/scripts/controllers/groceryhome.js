'use strict';

/**
 * @ngdoc function
 * @name groceryApp.controller:GroceryhomeCtrl
 * @description
 * # GroceryhomeCtrl
 * Controller of the groceryApp
 */
angular.module('groceryApp')
  .controller('GroceryhomeCtrl', function ($scope,cartService,$location,$state,$route,c,restcall) {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
$scope.cartItems=cartService.list;
$scope.authorMsg=c.greet();
$scope.deleteRow = function(row){
 cartService.deleteItem(row);
  };
 

console.log($scope.cartItems);
$scope.buy=function()
{

  restcall.call($scope.cartItems);
}
//$scope.data=(restcall.query());


//$scope.name= restcall.get();
console.log('hey '+$scope.data);
  });
