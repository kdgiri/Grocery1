'use strict';

/**
 * @ngdoc directive
 * @name groceryApp.directive:cart
 * @description
 * # cart
 */
angular.module('groceryApp')
  .directive('cellPhone', function () {
    return {
      
      restrict: 'A',
      require: 'ngModel',
      link: function postLink(scope, element, attr, ctrl) {
        
      	function customValidator(ngModelValue)
      	{
      		if(/[0-9]/.test(ngModelValue))
      		{
      			ctrl.$setValidity('numberValidity',true);
      		}	
      		else
      		{
      			ctrl.$setValidity('numberValidity',false);
      		}

      		if(ngModelValue===10)
      		{
      			ctrl.$setValidity('lengthValidity',true);
      		}
      		else
      		{
      			ctrl.$setValidity('lengthValidity',false);
      		}

      		return ngModelValue;
      	}

      	ctrl.$parsers.push(customValidator);
        
      }
    };
  });
 