'use strict';

/**
 * @ngdoc service
 * @name groceryApp.c
 * @description
 * # c
 * Provider in the groceryApp.
 */
angular.module('groceryApp')
  .provider('c', function () {

    // Private variables
    var salutation = 'Hello';

    // Private constructor
    function Greeter() {
      console.log("1");
      this.greet = function () {
        console.log("2");
        return salutation;
      };
    }

    // Public API for configuration
    this.setSalutation = function (s) {
      console.log("3");
      salutation = s;
    };

    // Method for instantiating
    this.$get = function () {
      console.log("now");
      return new Greeter();
    };
  });
