'use strict';

/**
 * @ngdoc service
 * @name groceryApp.cartService
 * @description
 * # cartService
 * Service in the groceryApp.
 */
angular.module('groceryApp')
  .service('cartService', function (restGet) {
    // AngularJS will instantiate a singleton by calling "new" on this function
    var items=[];
   
   var obj=function()
   {
   	restGet.success(function(data)
   	{
   		console.log(data);
   		
   		var jsonData = data; //Getting string data in response
          
          
          angular.forEach(jsonData, function(item,key){
           
            console.log(item+key);
 			if(key==='id')
 			{
 				item='Milk';
 			}else if(key==='userId')
 			{
 				item='Juice';
 			} 
 			else if(key==='title')
 			{
 				item='eggs'
 			}
 			else if(key==='body')
 			{
 				item='Bread'
 			}         	
              items.push(item);
            
            
          });
          
          
   		console.log(items);
   	});
	
   }
   this.item=obj();


    this.deleteItem = function (a) { 

	items.splice(items.indexOf(a), 1);  
	 };
	this.list=items;
  });
