'use strict';

/**
 * @ngdoc service
 * @name groceryApp.restGet
 * @description
 * # restGet
 * Factory in the groceryApp.
 */
angular.module('groceryApp')
  .factory('restGet', function ($http,$resource) {
    // Service logic
    // ...
   
    return $http.get("http://jsonplaceholder.typicode.com/posts/1");



 

    // Public API here
    
     
   /* we can use resource call for simplicity  
   return $resource("http://jsonplaceholder.typicode.com/posts/:id",{id: '100'},{
      get: {
        method: 'GET',
        params: {
        },
        isArray: true,
        transformResponse: function(data, header){
          var jsonData = JSON.parse(data); //Getting string data in response
          var notes = [];
          
          angular.forEach(jsonData, function(item,key){
           // var note = new Note();
            //note.noteTitle = item.title;
            console.log(item +key);
            if(item==='id')
            {
            }  else
            {
              notes.push(item);
            }
            
          });
          
          return notes;
        }
      }
    });*/
    
  });
