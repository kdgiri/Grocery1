'use strict';

/**
 * @ngdoc service
 * @name groceryApp.restcall
 * @description
 * # restcall
 * Factory in the groceryApp.
 */
angular.module('groceryApp')
  .factory('restcall',function ($http,$resource,$state,$location) {
    // Service logic
    // ...



return{
  call: function(addData)
  {
 return $http({
        
        url: "http://jsonplaceholder.typicode.com/posts/",
        method: "POST",
        data: addData,
      })
        .success(function(data) {
          $location.path('/about');
        });
  }
}


    // Public API here
    
        /*var data= $resource("http://jsonplaceholder.typicode.com/posts/10",{
          update:{
            method:'PUT'
          }
        });
    return data;*/
  });
