function submitValid() {
  var fName = document.getElementById("fnameInput").value;
  var lName = document.getElementById("lnameInput").value;
  var email = document.getElementById("emailInput").value;
  var invalidInput = 0;
  var word = /[a-z A-Z]+?/;
  var emailRegex = /\w+?@\w+?/;
  if (!word.test(fName)) {
    document.getElementById("fNameErr").innerHTML = "Please enter your first name";
    invalidInput += 1;
  } else {
    document.getElementById("fNameErr").innerHTML = "";
  }
  if (!word.test(lName)) {
    document.getElementById("lNameErr").innerHTML = "Please enter your last name";
    invalidInput += 1;
  } else {
    document.getElementById("lNameErr").innerHTML = "";
  }
  if (!emailRegex.test(email)) {
    document.getElementById("emailErr").innerHTML = "Please enter a valid email address";
    invalidInput += 1;
  } else {
    document.getElementById("emailErr").innerHTML = "";
  }
  if (invalidInput > 0) {
    return false;
  } else {
    return true;
  }
};

function login() {
  var userName = document.getElementById("userNameInput").value;
  var pw = document.getElementById("passwordInput").value;
  var pw2 = document.getElementById("password2Input").value;
  if (userName == "") {
    document.getElementById("unErr").innerHTML = "Enter your username";
  }
  if (pw != pw2) {
    document.getElementById("pw2Err").innerHTML = "Passwords do not match";
    document.getElementById("pwErr").innerHTML = "Passwords do not match";
  }
  if (pw == "") {
    document.getElementById("pwErr").innerHTML = "Enter a password";
  }
  if (pw2 == "") {
    document.getElementById("pw2Err").innerHTML = "Enter a password";
  }
  if (pw == pw2 && userName != "" && px != "" && pw2 != "") {
    alert("Successful Log In");
  }
};
function resetMe(){
	document.getElementById("fNameErr").innerHTML="";
	document.getElementById("lNameErr").innerHTML="";
	document.getElementById("emailErr").innerHTML="";	
	document.getElementById("unErr").innerHTML="";
	document.getElementById("pwErr").innerHTML="";	
	document.getElementById("pw2Err").innerHTML="";	
	}